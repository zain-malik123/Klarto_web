class AppConfig {
  // TODO: Replace with your actual EC2 server IP or domain name.
  // For local testing against a server on the same machine:
  // - Android Emulator: 'http://10.0.2.2:8080'
  // - iOS Simulator / Desktop / Web: 'http://localhost:8080'
  static const String baseUrl = 'https://klarto.io/api';
}