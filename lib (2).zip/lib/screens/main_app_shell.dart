import 'package:flutter/material.dart';
import 'package:klarto/screens/home_screen.dart';
import 'package:klarto/widgets/home/sidebar.dart';

class MainAppShell extends StatefulWidget {
  const MainAppShell({super.key});

  @override
  State<MainAppShell> createState() => _MainAppShellState();
}

class _MainAppShellState extends State<MainAppShell> {
  // In a real app, this would be managed by a state management solution
  // to control which page is shown. For now, we default to HomeScreen.
  final Widget _currentPage = const HomeScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          const Sidebar(), // The sidebar is always present
          Expanded(child: _currentPage), // The content area changes
        ],
      ),
    );
  }
}