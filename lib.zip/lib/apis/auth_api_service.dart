import 'dart:convert';
import 'package:http/http.dart' as http;

class AuthApiService {
  // IMPORTANT: Replace this with your actual EC2 server IP or domain name.
  static const String _baseUrl = 'http://your-ec2-ip-address/auth';

  Future<Map<String, dynamic>> signup({
    required String name,
    required String email,
    required String password,
  }) async {
    final url = Uri.parse('$_baseUrl/signup');

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'name': name,
        'email': email,
        'password': password,
      }),
    );

    final responseBody = json.decode(response.body);

    if (response.statusCode == 201) {
      // 201 Created: Success
      return {
        'success': true,
        'message': responseBody['message'] ?? 'Signup successful!'
      };
    } else {
      // Handle other status codes (e.g., 400 Bad Request, 409 Conflict)
      return {
        'success': false,
        'message': responseBody['message'] ?? 'An unknown error occurred.'
      };
    }
  }
}